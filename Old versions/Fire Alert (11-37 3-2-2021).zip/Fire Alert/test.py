import requests

Base = "http://127.0.0.1:5000/"

data = [{"name": "Rest", "likes": 45, "views": 135000},
		{"name": "Flask how to", "likes": 1, "views": 1000},
		{"name": "mob maps", "likes": 78, "views": 20900}]

for i in range(len(data)):
	response = requests.put(Base + "event/" + str(i), data[i])
	print(response.json())

input()
response = requests.get(Base + "event")
print(response)
response = requests.patch(Base + "event/2", {"views":99})
print(response.json())