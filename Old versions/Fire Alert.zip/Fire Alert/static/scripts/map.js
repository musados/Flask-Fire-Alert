
//alert("js file");

var fireCode = 1;
var	floodCode = 2;
var	plagueCode = 3;

var fireColor = "red";
var	floodColor = "blue";
var	plagueColor = "green";

var singleUri = "/event/";
var multipleUri = "/events";

var createMethod = "POST";
var updateMethod = "PUT";
var deleteMethod = "DELETE";
var queryMethod = "GET";

function getColorByEventType(type){
	if(type == 1)
		return "red";
	else if(type == 2)
		return "blue";
	else if(type == 3)
		return "green";
	else
		return "black";
}

function getNameByEventType(type){
	if(type == 1)
		return "Fire";
	else if(type == 2)
		return "Flood";
	else if(type == 3)
		return "Plague";
	else
		return "Unknown";
}

function getLatitude(latlon){
	if(latlon && latlon.indexOf(",") >0)
		return latlon.split(",")[0];
	else
		return "-1";
}

function getLongtitude(latlon){
	if(latlon && latlon.indexOf(",") >0)
		return latlon.split(",")[1];
	else
		return "-1";
}

class EventClass{
	constructor(event_id, title, description, event_type, lon, lat){
		this.event_id = event_id;
		this.title = title;
		this.description = description;
		this.eventType = event_type;
		this.lon = lon;
		this.lat = lat;
	}

	getMyColor(){
		var result = "grey";

		switch(this.eventType){
			case fireCode:
			result = fireColor;
			break;
			case floodCode:
			result = floodColor;
			break;
			case plagueCode:
			result = plagueColor;
			break;
			default:
			break;
		}

		return result;
	}

	getId(){
		return this.event_id;
	}

	getMyTypeName(){
		switch(this.eventType){
			case fireCode:
			return "FIRE";
			case floodCode:
			return "FLOOD";
			case plagueCode:
			return "PLAGUE";
			default:
			return "Unknown";
		}
	}

	asJson(){
		var js = '{ "id" :' + this.event_id +', "title" : "' + this.title  +
		'", "description" : "' + this.description +'", "type" :' + this.eventType +
		', "lon" : ' + this.lon + ', "lat" : ' + this.lat + '}';

alert(js);
		return JSON.parse(js);
	}
};


function createEvent(event, modal) {
    const formData = new FormData();
    formData.append('title', event.title);
    formData.append('description', event.description);
    formData.append('type', event.eventType);
    formData.append('lon', event.lon);
    formData.append('lat', event.lat);

    return fetch(singleUri + '1', {
        method: 'POST',
        body: formData
    }).then(response => response.json())
	.then(result => {
		console.log(result);
		var obj = JSON.stringify(result);
		var _js = JSON.parse(obj);
		if(_js["id"])
  			alert(`Event number ${_js["id"]} created!`);
  		else
  			alert(_js["message"]);

  		if(modal != null){
  			$(modal).modal('hide');
  		}
	})
	.catch(error => {
  		//console.error('Error:', error);
	});
}

function updateEvent(event, modal) {
    const formData = new FormData();
    formData.append('title', event.title);
    formData.append('description', event.description);
    formData.append('type', event.eventType);
    formData.append('lon', event.lon);
    formData.append('lat', event.lat);

    return fetch('/event/' + event.getId(), {
        method: 'PUT',
        body: formData
    }).then(response => response.json())
	.then(result => {
		console.log(result);
		var obj = JSON.stringify(result);
		var _js = JSON.parse(obj);
		console.log(obj);
		console.log(_js["id"]);
		if(_js["id"] && _js["id"] == event.getId()){
  			alert('Updating success!');
  		}
  		else{
  			alert(_js["message"]);
  		}
  		if(modal != null){
  			$(modal).modal('hide');
  		}
	})
	.catch(error => {
  		console.error('Error:', error);
	});
}

function getEvent(event) {
    const formData = new FormData();
    formData.append('title', event.title);
    formData.append('description', event.description);
    formData.append('type', event.eventType);

    return fetch('/map/event/' + event.getId(), {
        method: 'GET',
        body: formData
    }).then(response => response.json())
    .then(result => {
		console.log(result);
		var obj = JSON.stringify(result);
		var _js = JSON.parse(obj);
		
		//Check if the id field exist
		if(_js["id"] && _js["id"] == event.getId()){
  			alert('Updating success!');
  		}
  		else{
  			alert(_js["message"]);
  		}
  		if(modal != null){
  			$(modal).modal('hide');
  		}
	})
	.catch(error => {
  		console.error('Error:', error);
	});
}


/*createEvent(new EventClass(title="New event", description="Its just a description", eventType="2"))
   .then((json) => {
       alert(json);
    })
   .catch(error => error);*/

//Add event to the map
function addMapEvent(event, lng, lat, map){
	// create the popup
	/*var popup = new mapboxgl.Popup({ offset: 25 }).setHTML(
	`<strong>${event.title}</strong><p>${event.description}.</p><p>${event.getMyTypeName()}</p>`
	);

	// create DOM element for the marker
	var el = document.createElement('div');
	el.event_id = 'marker';

	// create the marker
	var point = [lng, lat];

	new mapboxgl.Marker({color: event.getMyColor()})
	.setLngLat(point)
	.setPopup(popup) // sets a popup on this marker
	.addTo(map);*/
}

//Add event to the map
function removeMapEvent(event){

	
}

//Add event to the map
function updateMapEvent(event){
	
}