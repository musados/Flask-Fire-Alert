
var geojson = {
  "type": "FeatureCollection",
  "features": [
    {
      "type": "Feature",
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.8895,
          32.47333
        ]
      },
      "properties": {
        "id": "1",
        "title": "Test1 title",
        "description": "Test 1 description",
        "type": "1"
      }
    },
    {
      "type": "Feature",
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.8895,
          32.4756
        ]
      },
      "properties": {
        "id": "2",
        "title": "Test2 title",
        "description": "Test 2 description",
        "type": "2"
      }
    },
    {
      "type": "Feature",
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.8995,
          32.47985
        ]
      },
      "properties": {
        "id": "3",
        "title": "Test3 title",
        "description": "Test 3 description",
        "type": "2"
      }
    },
    {
      "type": "Feature",
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.7895,
          32.59907
        ]
      },
      "properties": {
        "id": "4",
        "title": "Test4 title",
        "description": "Test 4 description",
        "type": "1"
      }
    },
    {
      "type": "Feature",
      "geometry": {
        "type": "Point",
        "coordinates": [
          34.6895,
          32.77456
        ]
      },
      "properties": {
        "id": "5",
        "title": "Test5 title",
        "description": "Test 5 description",
        "type": "3"
      }
    }
  ]
};
/*
var map = L.mapbox.map('map')
  .setView([38.909671288923, -77.034084142948], 13)
  .addLayer(L.mapbox.styleLayer('mapbox://styles/mapbox/light-v10'))
  .featureLayer.setGeoJSON(geojson);*/