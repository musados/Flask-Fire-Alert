const eventTypes = {
	FIRE: 1,
	FLOOD: 2,
	PLAGUE: 3
}

const eventTypesColors = {
	FIRE: "red",
	FLOOD: "blue",
	PLAGUE: "green"
}

const BASE = "/event/";

const RestApiUrls = {
	CREATE : BASE,
	UPDATE : BASE,
	DELETE : BASE,
	QUERY : "/events"
}

const RestApiMethods = {
	CREATE : "PUT",
	UPDATE : "PATCH",
	DELETE : "DELETE",
	QUERY : "/events"
}

class Event{
	constructor(id, title, description, event_type){
		this.id = id;
		this.title = title;
		this.description = description;
		this.eventType = event_type;
	}

	getMyColor(){
		var result = "grey";

		switch(this.eventType){
			case eventTypes.FIRE:
			result = eventTypesColors.FIRE;
			break;
			case eventTypes.FLOOD:
			result = eventTypesColors.FLOOD;
			break;
			case eventTypes.PLAGUE:
			result = eventTypesColors.PLAGUE;
			break;
			default:
			break;
		}

		return result;
	}

	getMyTypeName(){
		switch(this.eventType){
			case eventTypes.FIRE:
			return "FIRE";
			case eventTypes.FLOOD:
			return "FLOOD";
			case eventTypes.PLAGUE:
			return "PLAGUE";
			default:
			return "Unknown";
		}
	}

	asJson(){
		var js = '{ id :' + this.id +', title :' + this.title  +', description :' + this.description +', type :' + this.eventType + '}';

		return JSON.parse(js);
	}
}

function createNewEvent(event) {
    const formData = new FormData();
    formData.append('title', event.title);
    formData.append('description', event.description);
    formData.append('type', event.eventType);

    return fetch('http://example.com/api/v1/registration', {
        method: 'POST',
        body: formData
    }).then(response => response.json())
}

createNewProfile(Event(title="New event", description="Its just a description", eventType="2"))
   .then((json) => {
       alert(json);
    })
   .catch(error => error);


//Add event to the map
function addMapEvent(event, lng, lat, map){
	// create the popup
	var popup = new mapboxgl.Popup({ offset: 25 }).setHTML(
	`<strong>${event.title}</strong><p>${event.description}.</p><p>${event.getMyTypeName()}</p>`
	);

	// create DOM element for the marker
	var el = document.createElement('div');
	el.id = 'marker';

	// create the marker
	var point = [lng, lat];

	new mapboxgl.Marker({color: event.getMyColor()})
	.setLngLat(point)
	.setPopup(popup) // sets a popup on this marker
	.addTo(map);
}

//Add event to the map
function removeMapEvent(event){

	
}

//Add event to the map
function updateMapEvent(event){
	
}