
alert("js file");

var fireCode = 1;
var	floodCode = 2;
var	plagueCode = 3;

var fireColor = "red";
var	floodColor = "blue";
var	plagueColor = "green";

var singleUri = "/event/";
var multipleUri = "/events";

var createMethod = "POST";
var updateMethod = "PUT";
var deleteMethod = "DELETE";
var queryMethod = "GET";

class EventClass{
	constructor(id, title, description, event_type, lon, lat){
		this.id = id;
		this.title = title;
		this.description = description;
		this.eventType = event_type;
		this.lon = lon;
		this.lat = lat;
	}

	getMyColor(){
		var result = "grey";

		switch(this.eventType){
			case fireCode:
			result = fireColor;
			break;
			case floodCode:
			result = floodColor;
			break;
			case plagueCode:
			result = plagueColor;
			break;
			default:
			break;
		}

		return result;
	}

	getMyTypeName(){
		switch(this.eventType){
			case fireCode:
			return "FIRE";
			case floodCode:
			return "FLOOD";
			case plagueCode:
			return "PLAGUE";
			default:
			return "Unknown";
		}
	}

	asJson(){
		var js = '{ id :' + this.id +', title :' + this.title  +
		', description :' + this.description +', type :' + this.eventType +
		', lon :' + this.lon + ', lat :' + this.lat + '}';

		return JSON.parse(js);
	}
};


function createEvent(event) {
alert(window.location.host);
    const formData = new FormData();
    formData.append('title', event.title);
    formData.append('description', event.description);
    formData.append('type', event.eventType);
    return fetch(window.location.host + '/map/event/1', {
        method: 'POST',
        body: formData
    }).then(response => response.json())
}

/*function updateEvent(event) {
	alert("Cookie");
    const formData = new FormData();
    formData.append('title', event.title);
    formData.append('description', event.description);
    formData.append('type', event.eventType);

    return fetch(window.location.host + '/map/event/' + event.id, {
        method: 'PUT',
        body: formData
    }).then(response => response.json());
}*/


createEvent(new EventClass(title="New event", description="Its just a description", eventType="2"))
   .then((json) => {
       alert(json);
    })
   .catch(error => error);

//Add event to the map
function addMapEvent(event, lng, lat, map){
	// create the popup
	var popup = new mapboxgl.Popup({ offset: 25 }).setHTML(
	`<strong>${event.title}</strong><p>${event.description}.</p><p>${event.getMyTypeName()}</p>`
	);

	// create DOM element for the marker
	var el = document.createElement('div');
	el.id = 'marker';

	// create the marker
	var point = [lng, lat];

	new mapboxgl.Marker({color: event.getMyColor()})
	.setLngLat(point)
	.setPopup(popup) // sets a popup on this marker
	.addTo(map);
}

//Add event to the map
function removeMapEvent(event){

	
}

//Add event to the map
function updateMapEvent(event){
	
}