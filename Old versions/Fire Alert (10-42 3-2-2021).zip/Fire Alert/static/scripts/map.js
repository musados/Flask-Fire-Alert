//alert("js file");

var fireCode = 1;
var floodCode = 2;
var plagueCode = 3;

var fireColor = "red";
var floodColor = "blue";
var plagueColor = "green";

var singleUri = "/event/";
var multipleUri = "/events";

var createMethod = "POST";
var updateMethod = "PUT";
var deleteMethod = "DELETE";
var queryMethod = "GET";

function getColorByEventType(type) {
    if (type == 1)
        return "red";
    else if (type == 2)
        return "blue";
    else if (type == 3)
        return "green";
    else
        return "black";
}

function getNameByEventType(type) {
    if (type == 1)
        return "Fire";
    else if (type == 2)
        return "Flood";
    else if (type == 3)
        return "Plague";
    else
        return "Unknown";
}

function getLatitude(latlon) {
    if (latlon && latlon.indexOf(",") > 0)
        return latlon.split(",")[0];
    else
        return "-1";
}

function getLongtitude(latlon) {
    if (latlon && latlon.indexOf(",") > 0)
        return latlon.split(",")[1];
    else
        return "-1";
}

class EventClass {
    constructor(event_id, title, description, event_type, lon, lat) {
        this.event_id = event_id;
        this.title = title;
        this.description = description;
        this.eventType = event_type;
        this.lon = lon;
        this.lat = lat;
    }

    fromJson(json) {
        this.event_id = json['id'];
        this.title = json['title'];
        this.description = json['description'];
        this.eventType = json['type'];
        this.lon = json['lon'];
        this.lat = json['lat'];
    }

    getMyColor() {
        var result = "grey";

        switch (this.eventType) {
            case fireCode:
                result = fireColor;
                break;
            case floodCode:
                result = floodColor;
                break;
            case plagueCode:
                result = plagueColor;
                break;
            default:
                break;
        }

        return result;
    }

    getId() {
        return this.event_id;
    }

    getMyTypeName() {
        switch (this.eventType) {
            case fireCode:
                return "FIRE";
            case floodCode:
                return "FLOOD";
            case plagueCode:
                return "PLAGUE";
            default:
                return "Unknown";
        }
    }

    asJson() {
        var js = '{ "id" :' + this.event_id + ', "title" : "' + this.title +
            '", "description" : "' + this.description + '", "type" :' + this.eventType +
            ', "lon" : ' + this.lon + ', "lat" : ' + this.lat + '}';

        return JSON.parse(js);
    }

    asGeoJsonObject() {
        var js = {
            type: "Feature",
            geometry: {
                type: "Point",
                coordinates: [
                    this.lon,
                    this.lat
                ]
            },
            properties: {
                id: this.event_id,
                title: this.title,
                description: this.description,
                type: this.eventType
            }
        };

        return js;
    }
};

class EventList {
    constructor() {
        this.array = [];
    }


    deleteEvent(event_id) {
        var ev_index = -1;
        this.array.forEach(myFunction);

        function myFunction(value, index, array) {
            if (value.getId() == event_id)
                ev_index = index;
        }

        if (ev_index >= 0)
            this.array.splice(ev_index, 1);
    }

    addEvent(ev) {
        console.log(ev);
        if (ev) {
            this.deleteEvent(ev.getId());
            this.array.push(ev);
        }
    }

    getIdExist(id) {
        this.array.forEach(myFunction);

        function myFunction(value, index, array) {
            if (value.getId() == id)
                return index;
        }

        return -1;
    }

    getGeoJson() {

        var res_a = [];

        this.array.forEach(myFunction);

        function myFunction(value, index, array) {
            res_a.push(value.asGeoJsonObject());
        }
        var res = {
            type: "FeatureCollection",
            features: res_a
        };

        return res;
    }
}


var eventsList = new EventList();

function createEvent(event, modal) {
    const formData = new FormData();
    formData.append('title', event.title);
    formData.append('description', event.description);
    formData.append('type', event.eventType);
    formData.append('lon', event.lon);
    formData.append('lat', event.lat);


    return fetch(singleUri + '1', {
            method: 'POST',
            body: formData
        }).then(response => response.json())
        .then(result => {
            console.log(result);
            var obj = JSON.stringify(result);
            var _js = JSON.parse(obj);
            if (_js["id"]) {
                getAllEvents();
                alert(`Event number ${_js["id"]} created!`);
            } else
                alert(_js["message"]);

            if (modal != null) {
                $(modal).modal('hide');
            }
        })
        .catch(error => {
            //console.error('Error:', error);
        });
}

function updateEvent(event, modal) {
    const formData = new FormData();
    formData.append('title', event.title);
    formData.append('description', event.description);
    formData.append('type', event.eventType);
    formData.append('lon', event.lon);
    formData.append('lat', event.lat);

    return fetch('/event/' + event.getId(), {
            method: 'PUT',
            body: formData
        }).then(response => response.json())
        .then(result => {
            var obj = JSON.stringify(result);
            var _js = JSON.parse(obj);
            if (_js["id"] && _js["id"] == event.getId()) {
                getAllEvents();
                alert('Updating success!');
            } else {
                alert(_js["message"]);
            }
            if (modal != null) {
                $(modal).modal('hide');
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });
}

function deleteEvent(event_id) {

    return fetch('/event/' + event_id, {
            method: 'DELETE'
        }).then(response => response.json())
        .then(result => {
            console.log(result);
            var obj = JSON.stringify(result);
            var _js = JSON.parse(obj);
            if (_js["id"] && _js["id"] == event_id) {
                eventsList.deleteEvent(event_id);
                getAllEvents();
            } else {
                alert(_js["message"]);
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });
}

function getEvent(event) {
    const formData = new FormData();
    formData.append('title', event.title);
    formData.append('description', event.description);
    formData.append('type', event.eventType);

    return fetch('/event/' + event.getId(), {
            method: 'GET',
            body: formData
        }).then(response => response.json())
        .then(result => {
            console.log(result);
            var obj = JSON.stringify(result);
            var _js = JSON.parse(obj);

            //Check if the id field exist
            if (_js["id"] && _js["id"] == event.getId()) {
                alert('Updating success!');
                getAllEvents();
            } else {
                alert(_js["message"]);
            }
            if (modal != null) {
                $(modal).modal('hide');
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });
}


function getAllEvents() {

    return fetch('/events/', {
            method: 'GET'
        }).then(response => response.json())
        .then(result => {
            console.log(result);
            var obj = JSON.stringify(result);
            var obj2 = JSON.parse(obj);
            //var _js = JSON.stringify(obj2);
            //var _js2 = JSON.parse(_js);
            console.log(obj2[0]);
            var i;
            if (obj2 != null)
                obj2.forEach(addEventTolist);

            //}
            //_js.forEach(addEventTolist);

            function addEventTolist(value, index, array) {
                console.log("value: ");
                console.log(value['id']);
                console.log(value['title']);
                var e = new EventClass();
                e.fromJson(value);
                console.log(e.getId());
                eventsList.addEvent(e);
                console.log(eventsList.getGeoJson());
                var _geoJson = eventsList.getGeoJson();
                setMapMarkers(_geoJson);
                //console.log("list: ");
                console.log(eventsList);
            }

        })
        .catch(error => {
            console.error('Error:', error);
            setMapMarkers(geoJson);
        });
}
getAllEvents();
setInterval(getAllEvents, 8000);


/*createEvent(new EventClass(title="New event", description="Its just a description", eventType="2"))
   .then((json) => {
       alert(json);
    })
   .catch(error => error);*/

//Add event to the map
function addMapEvent(event, lng, lat, map) {
    // create the popup
    /*var popup = new mapboxgl.Popup({ offset: 25 }).setHTML(
    `<strong>${event.title}</strong><p>${event.description}.</p><p>${event.getMyTypeName()}</p>`
    );

    // create DOM element for the marker
    var el = document.createElement('div');
    el.event_id = 'marker';

    // create the marker
    var point = [lng, lat];

    new mapboxgl.Marker({color: event.getMyColor()})
    .setLngLat(point)
    .setPopup(popup) // sets a popup on this marker
    .addTo(map);*/
}

//Add event to the map
function removeMapEvent(event) {


}

//Add event to the map
function updateMapEvent(event) {

}