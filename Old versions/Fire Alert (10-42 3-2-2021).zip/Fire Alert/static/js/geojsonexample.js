var geojson = {
    "type": "FeatureCollection",
    "features": []
};
/*
var map = L.mapbox.map('map')
  .setView([38.909671288923, -77.034084142948], 13)
  .addLayer(L.mapbox.styleLayer('mapbox://styles/mapbox/light-v10'))
  .featureLayer.setGeoJSON(geojson);*/